/* ============================================================
   Legacy Roots NPO  shared site scripts
   Handles: welcome message, heritage/roots facts, volunteer CTA,
   contact form validation, enquiry form validation, gallery
   lightbox, and blog tab switching.
   ============================================================ */

/* ---- Home page: time-based welcome message ---- */
function updateWelcomeMessage() {
  const welcomeElement = document.getElementById('dynamicWelcome');
  if (!welcomeElement) return; // only runs on index.html

  const hour = new Date().getHours();
  let message = "Growing community heritage, one root at a time.";

  if (hour < 12) {
    message = "Good morning! Help us grow Pretoria's living heritage.";
  } else if (hour < 18) {
    message = "Good afternoon! Discover how we're restoring and regreening our community.";
  } else {
    message = "Good evening! Learn how Legacy Roots NPO safeguards our shared future.";
  }

  welcomeElement.textContent = message;
}

/* ---- Home page: volunteer call-to-action ---- */
function showVolunteerMessage() {
  alert("Thank you for your interest in volunteering! Please visit our Enquiry page to get started.");
  window.location.href = 'enquiry.html';
}

/* ---- Home page: rotating "Did You Know?" facts ---- */
const rootsFacts = [
  "Some tree root systems live for centuries, quietly outlasting the buildings around them.",
  "Urban greening projects can lower local temperatures by up to 5°C.",
  "Pretoria has over 50 declared heritage sites and monuments.",
  "Planting indigenous trees helps restore soil health as well as biodiversity.",
  "Community-led restoration projects build a sense of shared ownership over local heritage."
];

function showRandomFact() {
  const factElement = document.getElementById('heritageFact');
  if (!factElement) return; // only runs on index.html

  const randomFact = rootsFacts[Math.floor(Math.random() * rootsFacts.length)];
  factElement.textContent = randomFact;
}

/* ---- Contact page: form validation ---- */
function validateContactForm() {
  const name = document.getElementById('contact-name').value.trim();
  const email = document.getElementById('contact-email').value.trim();
  const message = document.getElementById('contact-message').value.trim();

  if (name === '' || email === '' || message === '') {
    alert('Please fill in all required fields before submitting.');
    return false;
  }
  alert('Thank you for contacting Legacy Roots NPO! We will respond soon.');
  return true;
}

/* ---- Enquiry page: form validation ---- */
function validateEnquiryForm() {
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  if (name === '' || email === '' || message === '') {
    alert('Please fill in all required fields before submitting.');
    return false;
  }
  alert('Thank you for your enquiry! Our team will be in touch.');
  return true;
}

/* ---- Projects page: gallery lightbox ---- */
function openLightbox(src) {
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');
  if (!lightbox || !lightboxImg) return;
  lightboxImg.src = src;
  lightbox.style.display = 'block';
}

function closeLightbox() {
  const lightbox = document.getElementById('lightbox');
  if (lightbox) lightbox.style.display = 'none';
}

/* ---- Blog page: tab switching ---- */
function openTab(tabName) {
  const tabs = document.querySelectorAll('.tab-content');
  const buttons = document.querySelectorAll('.tab-button');

  tabs.forEach(tab => tab.style.display = 'none');
  buttons.forEach(btn => btn.classList.remove('active-tab'));

  const activeTab = document.getElementById(tabName);
  if (activeTab) activeTab.style.display = 'block';

  event.target.classList.add('active-tab');
}

/* ---- Run on page load ---- */
document.addEventListener('DOMContentLoaded', function () {
  updateWelcomeMessage();
  showRandomFact();
  setInterval(showRandomFact, 10000); // rotate fact every 10 seconds
});