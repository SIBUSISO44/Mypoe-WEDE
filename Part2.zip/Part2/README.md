# Legacy Roots NPO Website Project

## Student Information
- Student Name: Sibusiso Wana
- Student Number: ST1052779
- Module Name & Code: WEDE WEBDEVELOPMENT
- Group: 5

## Project Overview
Legacy Roots NPO is a fictional non-profit organisation based in Pretoria, South Africa, dedicated to restoring cultural heritage monuments while promoting community greening and environmental stewardship. This repository contains the website built for Legacy Roots NPO as part of the Portfolio of Evidence (PoE). The project is completed in three parts:

- **Part 1 – Building the Foundation:** project planning, research, HTML structure. *(Completed)*
- **Part 2 – Designing the Visuals:** CSS styling, responsive design, UX optimisation. *(Completed)*
- **Part 3 – Adding Functionality and SEO:** JavaScript, forms, SEO optimisation. *(Completed)*

## What Part 1 Covers (Building the Foundation)

Part 1 focused on project initiation, planning, and the HTML foundation of the website.

1. **Identified the key advantages of an organisation having a website.**
   Legacy Roots NPO benefits from a website by reaching potential volunteers, donors, and community members beyond word-of-mouth, providing a permanent record of its restoration and greening projects, and giving the organisation credibility when approaching sponsors.

2. **Identified the key success indicators of a website in terms of organisational objectives.**
   Success is measured by: number of enquiry/volunteer form submissions, time spent on the Projects and Blog pages, and growth in newsletter/blog engagement — all tied to the organisation's goal of growing its volunteer base and donor network.

3. **Identified the key resources needed as a web developer to get started.**
   A code editor (VS Code), a browser for testing, Git/GitHub for version control, and free image/content resources for legally sourced media.

4. **Sourced images and other assets legally for use in web development.**
   All images used are either the student's own project assets or sourced from public domain/Creative Commons libraries.

5. **Utilised free online tools for preparing resources.**
   Tools such as Canva, Unsplash, and TinyPNG were used for logo design and image optimisation.

6. **Managed a file and folder structure appropriate for the website.**
   The project uses a clear root structure:
   Home page.html
About Us.html
Projects.html
blog.html
Enquiry.html
Contact Us.html
README.md
css/
style.css
js/
script.js
images/
favicon.jpg


7. **Used VS Code to create a project and web pages with HTML code.**
   All six pages were built and edited in VS Code.

8. **Linked the HTML pages of the website for a functional navigation system.**
   Every page shares an identical `<nav>` menu linking Home, About Us, Projects, Blog, Enquiry, and Contact Us — confirmed working across all six files.

9. **Created efficient and standards-compliant HTML code to control the structure of each page.**
   Each page uses semantic structure: `<nav>` for navigation, `<section>` for content areas, and `<footer>` for the footer.

10. **Added appropriate content and resources to the HTML structure of each page.**
    Each page contains organisation-relevant content: mission/vision/team (About Us), a project services grid (Projects), tabbed blog posts (Blog), and working contact/enquiry forms.

## What Part 2 Covers (Designing the Visuals)

Part 2 focused on CSS styling, responsive design, and visual presentation.

1. **Created and linked an external stylesheet across all six pages.**
   A single `css/style.css` file is linked on every page, keeping all styling centralised and consistent.

2. **Applied a consistent colour scheme across the website.**
   The website uses a green and brown heritage-themed palette: `#2e5339` (dark green), `#6d4c35` (warm brown), `#f5f0e6` (cream background), and `#ffffff` (white content areas).

3. **Styled the navigation bar to be horizontal and interactive.**
   The navbar uses flexbox for horizontal layout with smooth hover colour transitions on all links.

4. **Moved all inline styles into CSS classes.**
   All previously inline styles were refactored into semantic CSS classes such as `.about-mission`, `.service-card`, `.team-card`, `.form-section`, and `.heritage-fact-box`.

5. **Implemented responsive design without any external frameworks.**
   Media queries at 768px and 600px ensure the layout adapts correctly on tablets and mobile devices, with the navbar stacking vertically and flex layouts switching to column direction.

6. **Styled forms consistently across the Enquiry and Contact pages.**
   Form inputs, labels, selects, textareas, and submit buttons all share a consistent styled appearance defined in the stylesheet.

7. **Added hover effects and visual interactions.**
   Service cards on the Projects page lift on hover, navbar links change background colour on hover, and submit buttons darken on hover.

8. **Styled the lightbox, tabs, and footer globally.**
   The lightbox overlay, blog tab buttons, and footer are all styled through the external stylesheet with no remaining inline styles.

## What Part 3 Covers (Adding Functionality and SEO)

Part 3 focused on JavaScript functionality and form validation.

1. **Implemented a time-based dynamic welcome message on the Home page.**
   The `updateWelcomeMessage()` function detects the time of day and displays a contextually appropriate greeting using `document.getElementById('dynamicWelcome')`.

2. **Implemented a rotating heritage facts section on the Home page.**
   The `showRandomFact()` function selects a random fact from an array every 10 seconds and updates the `id="heritageFact"` element automatically on page load.

3. **Added form validation on the Enquiry page.**
   The `validateEnquiryForm()` function checks that name, email, and message fields are filled before submission and displays an appropriate alert on success or failure.

4. **Added form validation on the Contact page.**
   The `validateContactForm()` function applies the same validation logic to the contact form fields.

5. **Implemented an image lightbox on the Projects page.**
   The `openLightbox()` and `closeLightbox()` functions allow users to click any service card image and view it enlarged in a full-screen overlay.

6. **Implemented tab switching on the Blog page.**
   The `openTab()` function shows and hides blog content sections and updates the active tab button styling dynamically.

7. **Fixed the JavaScript file path across all pages.**
   The script tag was corrected from `src="script.js"` to `src="js/script.js"` on every page to ensure all functionality loads correctly.

## Website Goals and Objectives
- Raise awareness of Legacy Roots NPO's heritage restoration and greening work.
- Encourage volunteering and sponsorship through accessible enquiry and contact forms.
- Provide an engaging, responsive, and easy-to-navigate experience across devices.
- Deliver a fully functional website with working JavaScript across all six pages.

## Key Features and Functionality
- Six HTML pages: Home, About Us, Projects, Blog, Enquiry, Contact Us.
- Consistent navigation, header structure, and footer across all pages.
- External CSS stylesheet with no inline styles remaining.
- Responsive layout using media queries — no frameworks used.
- JavaScript: dynamic welcome message, rotating facts, form validation, lightbox gallery, and tab switching.
- Semantic HTML throughout: headings, paragraphs, sections, articles, forms, images, and links.

## Timeline and Milestones
| Milestone | Status |
|---|---|
| Website Project Proposal submitted & approved | Completed |
| Part 1 – HTML structure & project planning | Completed |
| Part 2 – CSS styling & responsive design | Completed |
| Part 3 – JavaScript functionality & SEO | Completed |

## References
- All project images are the student's own assets or sourced from public domain libraries.
- Google Fonts and no external CSS frameworks were used.
- VS Code was used as the primary development environment.